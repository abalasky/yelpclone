package io.balasky.saleatsbackend.persistence.models;

public class ErrorObject {



}
