package io.balasky.saleatsbackend.components;

public class CheckLogin {

}
